package com.example.projeto_dev_mobile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity3 extends AppCompatActivity {

    private EditText textoUrl;
    private WebView navegadorWeb;
    private Toolbar toolbarLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        textoUrl=(EditText) findViewById(R.id.escreverURL);
        navegadorWeb=(WebView) findViewById(R.id.navegador);
        toolbarLayout=(Toolbar) findViewById(R.id.toolbarDaHora);
       // toolbarLayout=(Toolbar) findViewById(R.id.toolbarDaHora);
        setSupportActionBar(toolbarLayout);
        setSupportActionBar(toolbarLayout);

        navegadorWeb.getSettings().setJavaScriptEnabled(true);
        navegadorWeb.setWebViewClient(new WebViewClient());
        navegadorWeb.loadUrl("http://www.google.com/");





    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menutoolbar,menu);
        return true;
    }




    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.botaoAcessar:
                if (textoUrl.getText().toString().isEmpty()){
                    Toast.makeText(this, "Insira uma URL", Toast.LENGTH_SHORT).show();
                }else{
                    navegadorWeb.loadUrl(textoUrl.getText().toString());
                }

                //Toast.makeText(this,"Você tocou no botao acessar", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.botaoVoltar:
                Toast.makeText(this,"Voltando",Toast.LENGTH_SHORT).show();
                if (navegadorWeb.canGoBack()){
                    navegadorWeb.goBack();
                }else{
                    Toast.makeText(this, "Sem páginas para voltar", Toast.LENGTH_SHORT).show();
                }
                return true;
            case R.id.botaoAvancar:
                if (navegadorWeb.canGoForward()){
                    navegadorWeb.goForward();
                }else{
                    Toast.makeText(this, "Sem páginas para avançar",Toast.LENGTH_SHORT).show();
                    return true;
                }
        }
        return super.onOptionsItemSelected(item);
    }
}