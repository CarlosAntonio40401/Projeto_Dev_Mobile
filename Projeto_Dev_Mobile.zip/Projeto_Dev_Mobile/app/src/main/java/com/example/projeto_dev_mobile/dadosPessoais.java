package com.example.projeto_dev_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dadosPessoais extends AppCompatActivity {


    private
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados_pessoais);


    }
}