package com.example.projeto_dev_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private EditText n1;
    private EditText n2;
    private TextView resultado;
    private Button soma;
    private Button subtracao;
    private Button  multiplicacao;
    private Button divisao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        resultado = findViewById(R.id.resultado);
        soma = findViewById(R.id.soma);
        subtracao = findViewById(R.id.subtracao);
        multiplicacao = findViewById(R.id.multiplicacao);
        divisao = findViewById(R.id.divisao);



        soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1N = Integer.parseInt(n1.getText().toString()); //ele pega o valor em String, precisa converter para inteiro
                int n2N = Integer.parseInt(n2.getText().toString());

                int resultadoN = n1N + n2N;

                resultado.setText("O resultado é: "+resultadoN);
            }
        });

        subtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1N=Integer.parseInt(n1.getText().toString());
                int n2N = Integer.parseInt(n2.getText().toString());

                int resultadoSubtracao = n1N -n2N;

                resultado.setText("O resultado é: "+resultadoSubtracao);
            }
        });

        multiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1N=Integer.parseInt(n1.getText().toString());
                int n2N = Integer.parseInt(n2.getText().toString());

                int resultadoMultiplicacao = n1N * n2N;

                resultado.setText("O resultado é: "+resultadoMultiplicacao);
            }
        });


        divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int n1N=Integer.parseInt(n1.getText().toString());
                int n2N = Integer.parseInt(n2.getText().toString());

                int resultadoDivisao = n1N / n2N;

                resultado.setText("O resultado é: "+resultadoDivisao);
            }
        });
    }

}