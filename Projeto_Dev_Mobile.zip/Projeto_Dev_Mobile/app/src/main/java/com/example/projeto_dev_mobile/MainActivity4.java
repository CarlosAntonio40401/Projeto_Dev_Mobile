package com.example.projeto_dev_mobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.example.projeto_dev_mobile.DAO.DAO;
import com.example.projeto_dev_mobile.adapter.RecycleViewAdapter;
import com.example.projeto_dev_mobile.objetos.Pessoa;

import java.util.ArrayList;
import java.util.List;

public class MainActivity4 extends AppCompatActivity {

    private EditText editTextNome;
    private EditText editTextIdade;
    private Switch switchSexo;
    private Button botaoSalvar;

    Context context;
     RecyclerView recyclerView;
    LinearLayout linearLayout;
    RecyclerView.Adapter recyclerViewAdapter;
    RecyclerView.LayoutManager  recyclerViewLayouManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        context=getApplicationContext();

        editTextNome=findViewById(R.id.editTextNome);
        editTextIdade=findViewById(R.id.editTextIdade);
        switchSexo=findViewById(R.id.switchSexo);
        botaoSalvar=findViewById(R.id.botaoSalvar);
        recyclerView=findViewById(R.id.recyclerView);

        buscaNoBanco();

        botaoSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (!(editTextNome.getText().toString().equals("") || editTextIdade.getText().toString().equals(""))) {
                    String sexo;
                    if (switchSexo.isChecked()) {
                        sexo = "F";
                    } else {
                        sexo = "M";
                    }

                    DAO dao = new DAO(getApplicationContext());
                    Pessoa pessoa = new Pessoa();
                    pessoa.setNome(editTextNome.getText().toString());
                    pessoa.setSexo(sexo);
                    pessoa.setIdade(Integer.valueOf(editTextIdade.getText().toString()));
                    dao.inseriPessoa(pessoa);
                    dao.close();

                    limpaFormulario();

                    buscaNoBanco();

                } else {
                    Toast.makeText(getApplicationContext(), "Por favor preencha todos os campos", Toast.LENGTH_SHORT).show();
                }

            }

        });
    }

    private void buscaNoBanco() {
        DAO dao2= new DAO(getApplicationContext());
        List<Pessoa> pessoas=dao2.buscaPessoa();
        List<String> nomes = new ArrayList<>();
        List<String> idades = new ArrayList<>();
        List<String> sexos = new ArrayList<>();
        String[] dados_nomes = new String[]{};
        String[] dados_idade = new String[]{};
        String[] dados_sexos = new String[]{};

        for (Pessoa pessoasBuscada : pessoas){
            nomes.add(pessoasBuscada.getNome());
            idades.add(String.valueOf(pessoasBuscada.getIdade()));
            sexos.add(String.valueOf(pessoasBuscada.getSexo()));

        }

        dados_nomes= nomes.toArray(new String[0]);
        dados_idade= idades.toArray(new String[0]);
        dados_sexos= sexos.toArray(new String[0]);

        recyclerViewLayouManager=new LinearLayoutManager(context);
        recyclerView.setLayoutManager(recyclerViewLayouManager);
        recyclerViewAdapter=new RecycleViewAdapter(context, dados_nomes, dados_idade,dados_sexos) ;
        recyclerView.setAdapter(recyclerViewAdapter);



    }

    private void limpaFormulario() {
        editTextNome.setText("");
        editTextIdade.setText("");
        switchSexo.setChecked(false);
        editTextNome.requestFocus();
    }
}